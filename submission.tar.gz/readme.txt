This is a simple snake game

Enter game:
Wait a few seconds on the title screen and let the game load
Press Enter to enter the game board
You can quit at anytime during game by pressing backspace

Control snake:
Use arrows on keyboard to control the direction of the snake
Let snake eat the mushroom and it will grow longer


Fail game:
At the beginning of each game, the snake will have 3 lives.
As the snake grows longer, it may step on its own body, which will reduce one life. 
Stepping on its own body will also reduce length, breaking the snake from the point being stepped. 
The snake should never touch the walls. 
Touching walls will end game directly!!!