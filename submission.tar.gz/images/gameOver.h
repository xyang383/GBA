/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 gameOver gameOver.png 
 * Time-stamp: Monday 11/19/2018, 01:54:37
 * 
 * Image Information
 * -----------------
 * gameOver.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GAMEOVER_H
#define GAMEOVER_H

extern const unsigned short gameOver[38400];
#define GAMEOVER_SIZE 76800
#define GAMEOVER_LENGTH 38400
#define GAMEOVER_WIDTH 240
#define GAMEOVER_HEIGHT 160

#endif

