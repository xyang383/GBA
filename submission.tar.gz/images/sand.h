/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 sand sand.jpg 
 * Time-stamp: Monday 11/19/2018, 11:12:40
 * 
 * Image Information
 * -----------------
 * sand.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SAND_H
#define SAND_H

extern const unsigned short sand[38400];
#define SAND_SIZE 76800
#define SAND_LENGTH 38400
#define SAND_WIDTH 240
#define SAND_HEIGHT 160

#endif

