/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=10x10 mushroom mushroom.jpg 
 * Time-stamp: Monday 11/19/2018, 11:02:20
 * 
 * Image Information
 * -----------------
 * mushroom.jpg 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef MUSHROOM_H
#define MUSHROOM_H

extern const unsigned short mushroom[100];
#define MUSHROOM_SIZE 200
#define MUSHROOM_LENGTH 100
#define MUSHROOM_WIDTH 10
#define MUSHROOM_HEIGHT 10

#endif

