/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=240x160 snake1 snake1.png 
 * Time-stamp: Monday 11/19/2018, 01:54:02
 * 
 * Image Information
 * -----------------
 * snake1.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SNAKE1_H
#define SNAKE1_H

extern const unsigned short snake1[38400];
#define SNAKE1_SIZE 76800
#define SNAKE1_LENGTH 38400
#define SNAKE1_WIDTH 240
#define SNAKE1_HEIGHT 160

#endif

