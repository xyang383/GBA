/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=10x10 garbage garbage.png 
 * Time-stamp: Monday 11/19/2018, 12:19:07
 * 
 * Image Information
 * -----------------
 * garbage.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GARBAGE_H
#define GARBAGE_H

extern const unsigned short garbage[100];
#define GARBAGE_SIZE 200
#define GARBAGE_LENGTH 100
#define GARBAGE_WIDTH 10
#define GARBAGE_HEIGHT 10

#endif

