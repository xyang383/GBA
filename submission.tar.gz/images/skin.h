/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=10x10 skin skin.png 
 * Time-stamp: Monday 11/19/2018, 11:07:54
 * 
 * Image Information
 * -----------------
 * skin.png 10@10
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SKIN_H
#define SKIN_H

extern const unsigned short skin[100];
#define SKIN_SIZE 200
#define SKIN_LENGTH 100
#define SKIN_WIDTH 10
#define SKIN_HEIGHT 10

#endif

